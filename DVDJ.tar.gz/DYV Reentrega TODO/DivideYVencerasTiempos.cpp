#include "stdlib.h"
#include <iostream>
#include "string.h"
#include <sys/time.h>

using namespace std;

struct solucion{
       int origen;
       int final;       
};


bool isVocal(char c){
     if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ) return true;
     return false;
}

bool isConsonante(char c){
     if (c == 'b' || c == 'c' || c == 'd' || c == 'f' || c == 'g' || c == 'h' || c == 'j' || c == 'k' || c == 'l' 
         || c == 'm' || c == 'n' || c == '�' || c == 'p' || c == 'q' || c == 'r' || c == 's' || c == 't' 
         || c == 'v' || c == 'w' || c == 'x' || c == 'y' || c == 'z' ) return true;
     return false;
}

bool pequeno(int i, int j){
     return i==j;     
}

solucion combinar(solucion s2,solucion s1, char* palabra, int m){
         solucion s;
         
         int origenNuevaPosibleSolucion;
         int finalNuevaPosibleSolucion ;
         //cout << "Combinar: m= " << m << " s1 = " << s1.origen << "," << s1.final << "; s2 = " << s2.origen << "," << s2.final;
         if(  (isVocal(palabra[m]) && isConsonante(palabra[m+1]))   
            || (isConsonante(palabra[m]) && isVocal(palabra[m+1])) ){
                             //Si las soluciones mayores de ambas palabras coinciden con la 
                             if( (m == s1.final) && (m+1 == s2.origen) ){
                                  s.origen = s1.origen;  
                                  s.final = s2.final;   
                                  //cout << " Solucion = (" << s.origen << "," << s.final << ")" << endl;
                                  return s; 
                             }
                             //Si solo coincide la solucion de la izquierda, entonces tendremos que recorrer la derecha
                             else if (m == s1.final){
                                  origenNuevaPosibleSolucion = s1.origen;
                                  
                                  int i = m+1;
                                  finalNuevaPosibleSolucion = m+1;
                                  while((isVocal(palabra[i]) && isConsonante(palabra[i+1]))   
                                         || (isConsonante(palabra[i]) && isVocal(palabra[i+1]))){
                                                       finalNuevaPosibleSolucion++; 
                                                       i++;                          
                                  }      
                                       
                             }
                             //Si solo coincide la solucion de la derecha, entonces tendremos que recorrer la izquierda
                             else if(m+1 == s2.origen){
                                  finalNuevaPosibleSolucion = s2.final;   
                                  
                                  int i = m;
                                  origenNuevaPosibleSolucion = m;
                                  while((isVocal(palabra[i]) && isConsonante(palabra[i-1]))   
                                         || (isConsonante(palabra[i]) && isVocal(palabra[i-1]))){
                                                       origenNuevaPosibleSolucion--;  
                                                       i--;                         
                                         }  
                             }
                             else{
                                  int i = m;
                                  origenNuevaPosibleSolucion = m;
                                  while((isVocal(palabra[i]) && isConsonante(palabra[i-1]))   
                                         || (isConsonante(palabra[i]) && isVocal(palabra[i-1]))){
                                                       origenNuevaPosibleSolucion--;     
                                                       i--;                      
                                  } 
                                  
                                  int j = m+1;
                                  finalNuevaPosibleSolucion = m+1;
                                  while((isVocal(palabra[j]) && isConsonante(palabra[j+1]))   
                                         || (isConsonante(palabra[j]) && isVocal(palabra[j+1]))){
                                                       finalNuevaPosibleSolucion++; 
                                                       j++;                          
                                  }      
                             }
                             
                             if((s1.final-s1.origen) >= (s2.final-s2.origen)){
                                         if((s1.final-s1.origen) >= (finalNuevaPosibleSolucion - origenNuevaPosibleSolucion) ){
                                                s.origen = s1.origen;
                                                s.final = s1.final;                        
                                         }    
                                         else{
                                                s.origen = origenNuevaPosibleSolucion;
                                                s.final = finalNuevaPosibleSolucion;    
                                         }                  
                             }              
                             else{
                                         if((s2.final-s2.origen) > (finalNuevaPosibleSolucion - origenNuevaPosibleSolucion) ){
                                                s.origen = s2.origen;
                                                s.final = s2.final;                        
                                         }    
                                         else{
                                                s.origen = origenNuevaPosibleSolucion;
                                                s.final = finalNuevaPosibleSolucion;    
                                         }              
                             }
         }  
         else{
              if(  (s1.final-s1.origen) >= (s2.final-s2.origen) ){
                               s.origen = s1.origen;
                               s.final = s1.final;   
              }     
              else{
                   s.origen = s2.origen;
                   s.final = s2.final;    
              }
         } 
            //cout << " Solucion = (" << s.origen << "," << s.final << ")" << endl;
          return s;      
}

void print(char* palabra, int i, int j, int m){
     cout << "Dividir " << endl << "     Palabra 1: " ;
              for(; i<=m; ){
                   cout << palabra[i];
                   i++;
              }
              cout << endl;
              cout << "     Palabra 2: " ;
              for(m = m+1; m <= j; m++){
                   cout << palabra[m];
              }
              cout << endl;     
}

solucion DYV(char* palabra, int i, int j){

         if(pequeno(i, j)){
                       solucion s;
                       s.origen = i;
                       s.final = j;              
                       return s;
         }      
         else{
              int m = (i+j-1)/2;

              //print(palabra, i, j, m);
              
              //palabra << "; i= " << i << ", m = " << m << ", j= " << j << endl;
              return combinar(DYV(palabra, m+1, j), DYV(palabra, i, m), palabra, m);     
         }

}

int main(){
    int numeroPalabras;
    cin >> numeroPalabras;
    for(int i = 0; i < numeroPalabras; i++){
	    struct timeval ti, tf;
	    double tiempo;
	    char* palabra;
	    solucion s;

	    cin >> (palabra = new char);


	    gettimeofday(&ti, NULL);   // Instante inicial
	    s = DYV(palabra, 0, strlen(palabra)-1);
	    gettimeofday(&tf, NULL);   // Instante final
	    tiempo= (tf.tv_sec - ti.tv_sec)*1000 + (tf.tv_usec - ti.tv_usec)/1000.0;


	    cout << "Palabra = " << palabra << endl;
	    cout << "Solucion = ";
	    for(int i = s.origen; i<= s.final; i++){
		    cout << palabra[i];        
	    }
	    cout << endl;
	    cout << "Longitud = " << (s.final-s.origen)+1 << " (" << s.origen << "," << s.final << "); Tiempo = " << tiempo << " mseg" << endl;
	    cout << endl << endl;
    }
   
return 0;    
}
