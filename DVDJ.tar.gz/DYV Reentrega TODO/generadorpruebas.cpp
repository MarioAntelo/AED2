#include "string.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>  
#include <time.h>    
#include <cmath> 

using namespace std;

bool vocal = false; //Utilizado para alternar vocales y consonantes

char generarChar(int n){
	char c;
	char vocales[5];
	vocales[0] = 'a';
	vocales[1] = 'e';
	vocales[2] = 'i';
	vocales[3] = 'o';
	vocales[4] = 'u';

	int aleatorio = (1 + rand() % 5);

	if(n == 1){
		//Generamos una vocal
			c = vocales[aleatorio-1];
	}
	else if(n == 2){
			//Generamos una consonante o una vocal
			c = 'a'+ (  rand() % ('z' - 'a') );	
	}
	else if (n == 3){
		if(vocal == true){
			c = vocales[aleatorio-1];
			vocal = false;
		}
		else {
			while(true){
				c = 'a'+ (  rand() % ('z' - 'a') );
				if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u');
				else break;
			}
			vocal = true;
		}

	}

	return c;
}

string generarPalabra(int n, int aleatorio){
	string palabra;
	for(int i=0; i<aleatorio; i++){
		palabra+=generarChar(n);
	}
	return palabra;
}

string a(int n){
	string a;
	int pf = n/4;
	int medio = n/2;
	for(int i = 0; i < pf; i++){
		a+="ab";
	}

	for(int i = 0; i < medio; i++){
		a+="ba";
	}

	for(int i = 0; i < pf; i++){
		a+="ab";
	}
	return a;
	
	
}

int main(){

 	srand(time(NULL));
 	ofstream f("generador.out", ios::out);
	f << 15 << endl;

	f << a(4) << endl;	
	f << a(4) << endl;
	f << a(8) << endl;
	f << a(16) << endl;
	f << a(32) << endl;
	f << a(64) << endl;
	f << a(128) << endl;
	f << a(256) << endl;
	f << a(512) << endl;
	f << a(1024) << endl;
	f << a(2048) << endl;
	f << a(4096) << endl;
	f << a(8192) << endl;
	f << a(16536) << endl;
	f << a(32768) << endl;

 	f.close();

return 0;
}
