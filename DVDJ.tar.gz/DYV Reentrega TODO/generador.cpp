#include "string.h"
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>  
#include <time.h>    

using namespace std;

bool vocal = false; //Utilizado para alternar vocales y consonantes

char generarChar(int n){
	char c;
	char vocales[5];
	vocales[0] = 'a';
	vocales[1] = 'e';
	vocales[2] = 'i';
	vocales[3] = 'o';
	vocales[4] = 'u';

	int aleatorio = (1 + rand() % 5);

	if(n == 1){
		//Generamos una vocal
			c = vocales[aleatorio-1];
	}
	else if(n == 2){
			//Generamos una consonante o una vocal
			c = 'a'+ (  rand() % ('z' - 'a') );	
	}
	else if (n == 3){
		if(vocal == true){
			c = vocales[aleatorio-1];
			vocal = false;
		}
		else {
			while(true){
				c = 'a'+ (  rand() % ('z' - 'a') );
				if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u');
				else break;
			}
			vocal = true;
		}

	}

	return c;
}

string generarPalabra(int n, int numeroMaxCaracteres){
	string palabra;
	int aleatorio = (1 + rand() % numeroMaxCaracteres);
	for(int i=0; i<aleatorio; i++){
		palabra+=generarChar(n);
	}
	return palabra;
}

int main(){
	int numeroPalabras;
	int numeroMaxCaracteres;
	cin >> numeroPalabras;
	cin >> numeroMaxCaracteres;
	int m = numeroPalabras/3;

 	srand(time(NULL));
 	ofstream f("generador.out", ios::out);
	f << numeroPalabras << endl;
 	//Generaremos todos los caracteres vocales
 	for(int i = 0; i < m; i++){
		string a;
		a = generarPalabra(1, numeroMaxCaracteres);
		f << a << endl;
 	} 
 	//Generamos vocales y caracteres aleatoriamente
 	for(int i = 0; i < m; i++){
		f << generarPalabra(2, numeroMaxCaracteres) << endl;
 	} 
 	//Geeneramos todos los caracteres cumplen la condición de alternancia
 	for(int i = 0; i <= m; i++){
		f << generarPalabra(3, numeroMaxCaracteres) << endl;
 	}
 	f.close();

return 0;
}
