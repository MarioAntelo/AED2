#include "stdlib.h"
#include <iostream>
#include "string.h"
#include <sys/time.h>

using namespace std;

struct solucion{
       int origen;
       int final;       
};

bool isVocal(char c){
     if(c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u' ) return true;
     return false;
}

bool isConsonante(char c){
     if (c == 'b' || c == 'c' || c == 'd' || c == 'f' || c == 'g' || c == 'h' || c == 'j' || c == 'k' || c == 'l' 
         || c == 'm' || c == 'n' || c == '�' || c == 'p' || c == 'q' || c == 'r' || c == 's' || c == 't' 
         || c == 'v' || c == 'w' || c == 'x' || c == 'y' || c == 'z' ) return true;
     return false;
}

solucion dyvIterativo(char* palabra){
         solucion s;
         s.origen = 0;
         s.final = 0;
         int origenParcial=0;
         int finalParcial=0;
         int j = 0;
                 
         while(j < (signed)strlen(palabra)){
                  if ((isVocal(palabra[j]) && isConsonante(palabra[j+1]))
                     || (isConsonante(palabra[j]) && isVocal(palabra[j+1]))){
                             finalParcial++;                  
                  }
                  else{  
                         
                             if((finalParcial-origenParcial) > (s.final-s.origen)){
                                        s.origen = origenParcial;
                                        s.final = finalParcial;  
                             }                  
                             origenParcial = j+1;
                             finalParcial = j+1;
                  } 
                  j++;      
         }
         return s;
                  
}



int main(){
    int numeroPalabras;
    cin >> numeroPalabras;
    for(int i = 0; i < numeroPalabras; i++){
	    struct timeval ti, tf;
	    double tiempo;
	    char* palabra;
	    solucion s;

	    cin >> (palabra = new char);


	    gettimeofday(&ti, NULL);   // Instante inicial
	    s = dyvIterativo(palabra);
	    gettimeofday(&tf, NULL);   // Instante final
	    tiempo= (tf.tv_sec - ti.tv_sec)*1000 + (tf.tv_usec - ti.tv_usec)/1000.0;


	    cout << "Palabra = " << palabra << endl;
	    cout << "Solucion = ";
	    for(int i = s.origen; i<= s.final; i++){
		    cout << palabra[i];        
	    }
	    cout << endl;
	    cout << "Longitud = " << (s.final-s.origen)+1 << " (" << s.origen << "," << s.final << "); Tiempo = " << tiempo << " mseg" << endl;
	    cout << endl << endl;
    }
    
return 0;    
}
